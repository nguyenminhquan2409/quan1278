document.addEventListener("DOMContentLoaded", function () {
  const accountButton = document.querySelector(".account-btn");
  const menu = document.getElementById("subMenu");
  let isMenuVisible = false;

  // Hiển thị hoặc ẩn menu khi nhấp đúp vào nút Account
  accountButton.addEventListener("dblclick", function () {
    toggleMenu();
  });

  // Hiển thị menu khi nhấp đúp vào nút Account
  function toggleMenu() {
    menu.style.display = menu.style.display === "block" ? "none" : "block";
    isMenuVisible = menu.style.display === "block";
  }

  // Điều hướng khi nhấp vào các nút trong menu
  const loginButton = menu.querySelector("button:nth-child(1)");
  const settingsButton = menu.querySelector("button:nth-child(2)");
  const profileButton = menu.querySelector("button:nth-child(3)");
  
  loginButton.addEventListener("click", function () {
    window.location.href = "login.html"; // Thay "/login" bằng URL cho trang đăng nhập
  });

  settingsButton.addEventListener("click", function () {
    window.location.href = "settings.html"; // Thay "/settings" bằng URL cho trang cài đặt
  });

  profileButton.addEventListener("click", function () {
    window.location.href = "profile.html"; // Thay "/profile" bằng URL cho trang hồ sơ
  });
  
  

  // Theo dõi vị trí chuột và ẩn menu nếu cách xa hơn 75 px
  document.addEventListener("mousemove", function (event) {
    if (isMenuVisible) {
      const accountRect = accountButton.getBoundingClientRect();
      const menuRect = menu.getBoundingClientRect();
      const mouseX = event.clientX;
      const mouseY = event.clientY;

      // Kiểm tra khoảng cách giữa con trỏ và các cạnh của menu hoặc nút Account
      const isOutsideAccount =
        mouseX < accountRect.left - 75 ||
        mouseX > accountRect.right + 75 ||
        mouseY < accountRect.top - 75 ||
        mouseY > accountRect.bottom + 75;
      const isOutsideMenu =
        mouseX < menuRect.left - 75 ||
        mouseX > menuRect.right + 75 ||
        mouseY < menuRect.top - 75 ||
        mouseY > menuRect.bottom + 75;

      // Ẩn menu nếu chuột cách xa cả nút Account và menu hơn 75 px
      if (isOutsideAccount && isOutsideMenu) {
        menu.style.display = "none";
        isMenuVisible = false;
      }
    }
  });

  // Ẩn menu khi nhấp ra ngoài nút Account và menu
  document.addEventListener("click", function (event) {
    if (!accountButton.contains(event.target) && !menu.contains(event.target)) {
      menu.style.display = "none";
      isMenuVisible = false;
    }
  });
});

document.addEventListener("DOMContentLoaded", function () {
  const notificationIcon = document.querySelector(".notification-icon");
  let isContentVisible = false;

  // Hiển thị nội dung khi nhấn đúp
  notificationIcon.addEventListener("dblclick", function () {
    notificationIcon.classList.add("show");
    isContentVisible = true; // Đánh dấu nội dung đang hiển thị
  });

  // Theo dõi di chuyển chuột và tính khoảng cách
  document.addEventListener("mousemove", function (event) {
    if (isContentVisible) {
      const iconRect = notificationIcon.getBoundingClientRect();
      const mouseX = event.clientX;
      const mouseY = event.clientY;

      // Tính khoảng cách giữa chuột và trung tâm của nút chuông
      const distanceX = Math.abs(mouseX - (iconRect.left + iconRect.width / 2));
      const distanceY = Math.abs(mouseY - (iconRect.top + iconRect.height / 2));
      const distance = Math.sqrt(distanceX * distanceX + distanceY * distanceY);

      // Ẩn nội dung nếu chuột cách biểu tượng hơn 75px (khoảng 2cm)
      if (distance > 75) {
        notificationIcon.classList.remove("show");
        isContentVisible = false; // Đánh dấu nội dung đã bị ẩn
      }
    }
  });

  // Đóng nội dung khi nhấp bên ngoài phần tử
  document.addEventListener("click", function (event) {
    if (!notificationIcon.contains(event.target)) {
      notificationIcon.classList.remove("show");
      isContentVisible = false;
    }
  });
});
const buttons = document.querySelectorAll(".library-button");

buttons.forEach((button, index) => {
  button.addEventListener("mouseenter", () => {
    const type = button.getAttribute("data-type");
    const tooltip = document.querySelectorAll(".tooltip")[index]; // Lấy tooltip tương ứng

    if (type === "plus") {
      tooltip.textContent = "Thêm Thư Viện";
    } else if (type === "arrow") {
      tooltip.textContent = "Xem Thêm";
    }

    tooltip.style.top = `${
      button.getBoundingClientRect().bottom + window.scrollY + 8
    }px`; // Căn chỉnh tooltip
    tooltip.style.left = `${
      button.getBoundingClientRect().left + window.scrollX
    }px`;
  });
});
function moveSlide1(step) {
  const container = document.getElementById("playlist-slider1");
  const itemWidth = container.children[0].offsetWidth + 15; // Chiều rộng của một playlist card + khoảng cách

  // Di chuyển theo số bước (một bước là một item)
  container.scrollBy({
    left: itemWidth * step,
    behavior: "smooth"
  });
}

function moveSlide2(step) {
  const container = document.getElementById("playlist-slider2");
  const itemWidth = container.children[0].offsetWidth + 15; // Chiều rộng của một playlist card + khoảng cách
  const scrollAmount = itemWidth * step; // Khoảng di chuyển mỗi bước

  container.scrollBy({
    left: scrollAmount,
    behavior: "smooth"
  });
}
function redirectToNewPage() {
  // Thay URL này bằng trang đích bạn muốn
  window.location.href = "notification.html";
}
function moveSlide3(step) {
  const container = document.getElementById("playlist-slider3");
  const itemWidth = container.children[0].offsetWidth + 15; // Chiều rộng của một playlist card + khoảng cách
  const scrollAmount = itemWidth * step; // Khoảng di chuyển mỗi bước

  container.scrollBy({
    left: scrollAmount,
    behavior: "smooth"
  });
}
// Hàm để hiển thị tất cả nội dung


// Hàm để chỉ hiển thị "Những bản nhạc thịnh hành nhất hiện tại"
function showMusicContent() {
   document.getElementById("trendingMusic").style.display = "block";
  document.getElementById("musicCollection").style.display = "none";
  document.getElementById("trendingMusic1").style.display = "block";
  document.getElementById("trendingMusic2").style.display = "none";
 
}
function showPodcastContent() {
  document.getElementById("trendingMusic").style.display = "none";
 document.getElementById("musicCollection").style.display = "none";
 document.getElementById("trendingMusic1").style.display = "none";
 document.getElementById("trendingMusic2").style.display = "block";

}

// JavaScript

const musicCollection = document.querySelector('.playlist-section1');
const musicCollection2 = document.querySelector('.playlist-section2');
const musicCollection3 = document.querySelector('.playlist-section3');
const musicCollection1 = document.querySelector('.music-collection');
const body = document.body;

musicCollection.addEventListener('mouseenter', () => {
    // Khi hover: Đổi nền và có thể áp dụng màu trộn
    body.style.background = 'linear-gradient(to left, #4b3f49, #121212)';
    body.style.backgroundBlendMode = 'multiply'; // Kiểu trộn (có thể thử 'screen', 'overlay', etc.)
});

musicCollection.addEventListener('mouseleave', () => {
    // Khi rời khỏi: Quay lại nền cũ
    body.style.background = '';
   
});
musicCollection1.addEventListener('mouseenter', () => {
  // Khi hover: Đổi nền và có thể áp dụng màu trộn
  body.style.background = 'linear-gradient(to left, #4b3f49, #121212)';



  body.style.backgroundBlendMode = 'multiply'; // Kiểu trộn (có thể thử 'screen', 'overlay', etc.)
});

musicCollection1.addEventListener('mouseleave', () => {
  // Khi rời khỏi: Quay lại nền cũ
  body.style.background = '';
 
});
musicCollection2.addEventListener('mouseenter', () => {
  // Khi hover: Đổi nền và có thể áp dụng màu trộn
  body.style.background = 'linear-gradient(to left, #4b3f49, #121212)';



  body.style.backgroundBlendMode = 'multiply'; // Kiểu trộn (có thể thử 'screen', 'overlay', etc.)
});

musicCollection2.addEventListener('mouseleave', () => {
  // Khi rời khỏi: Quay lại nền cũ
  body.style.background = '';
 
});
musicCollection3.addEventListener('mouseenter', () => {
  // Khi hover: Đổi nền và có thể áp dụng màu trộn
  body.style.background = 'linear-gradient(to left, #4b3f49, #121212)';



  body.style.backgroundBlendMode = 'multiply'; // Kiểu trộn (có thể thử 'screen', 'overlay', etc.)
});

musicCollection3.addEventListener('mouseleave', () => {
  // Khi rời khỏi: Quay lại nền cũ
  body.style.background = '';
 
});

function searchPlaylists() {
  const input = document.getElementById('searchInput');
  const filter = input.value.toLowerCase();
  
  // Select all playlist cards across different classes
  const playlists = document.querySelectorAll('.playlist-card, .playlist-card1, .playlist-card2');
  let visiblePlaylists = 0; // Track number of visible playlists
  
  playlists.forEach((playlist) => {
    const text = playlist.innerText || playlist.textContent;
    if (text.toLowerCase().indexOf(filter) > -1) {
      playlist.style.display = "block"; // Show playlist if it matches
      visiblePlaylists++;
    } else {
      playlist.style.display = "none"; // Hide playlist if it doesn't match
    }
  });

  // Select the <h2> elements in both sections and hide them if any playlists are found
  const headings = [
    document.querySelector('.playlist-section1 h2'),
    document.querySelector('.playlist-section2 h2'),
    document.querySelector('.playlist-section3 h2')
  ];
  
  headings.forEach(heading => {
    if (visiblePlaylists > 0) {
      heading.style.display = "none"; // Hide the <h2> element
    }
  });
  
  const buttonClasses = [
    '.slider-button.prev1',
    '.slider-button.prev2',
    '.slider-button.prev3',
    '.slider-button.next1',
    '.slider-button.next2',
    '.slider-button.next3'
  ];
  
  buttonClasses.forEach(className => {
    const button = document.querySelector(className); // Tìm phần tử theo class
    if (button) {  // Kiểm tra nếu phần tử tồn tại
      if (visiblePlaylists > 0) {
        button.style.display = "none"; // Ẩn nút
      } 
    }
  });
  function adjustSliderWidth(sliderId, visiblePlaylists) {
    const slider = document.getElementById(sliderId);
    if (visiblePlaylists > 0) {
      slider.style.width = `${visiblePlaylists * 220}px`;
    } else {
      slider.style.width = "100%";
    }
  }
  
  adjustSliderWidth('playlist-slider2', visiblePlaylists);
  adjustSliderWidth('playlist-slider1', visiblePlaylists);
  adjustSliderWidth('playlist-slider3', visiblePlaylists);
  




}






